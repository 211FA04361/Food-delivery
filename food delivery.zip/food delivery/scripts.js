document.addEventListener("DOMContentLoaded", function () {
    const pages = {
        home: document.getElementById("home"),
        services: document.getElementById("services"),
        contact: document.getElementById("contact"),
        recipes: document.getElementById("recipes"),
        recipeDetail: document.getElementById("recipe-detail"),
        login: document.getElementById("login"),
        signup: document.getElementById("signup")
    };

    const recipeData = {
        1: {
            title: "Creamy Cottage Cheese Pasta",
            description: "Delicious pasta tossed in a rich and creamy cottage cheese sauce with herbs.",
            image: "creamy pasta.jpg",
            ingredients: [
                "Pasta (any type)",
                "Cottage cheese",
                "Garlic",
                "Olive oil",
                "Parsley",
                "Salt and pepper to taste"
            ],
            preparation: "Cook the pasta until al dente. In a separate pan, sauté garlic in olive oil, add cottage cheese, and mix until creamy. Toss the cooked pasta with the sauce, season with salt, pepper, and garnish with parsley."
        },        
        2: {
            title: "Margherita Pizza",
            description: "Fresh basil, mozzarella, and tomato sauce on a crispy crust.",
            image: "margherita-pizza.jpg",
            ingredients: ["Pizza dough", "Tomato sauce", "Mozzarella cheese", "Fresh basil"],
            preparation: "Spread tomato sauce on the dough, top with mozzarella and basil, and bake."
        },
        3: {
            title: "Spaghetti Carbonara",
            description: "Italian pasta with creamy sauce, pancetta, and Parmesan.",
            image: "spaghetti carbonar.jpeg.jpg",
            ingredients: ["Spaghetti", "Pancetta", "Eggs", "Parmesan cheese", "Black pepper"],
            preparation: "Cook spaghetti, mix with pancetta, eggs, and Parmesan to create a creamy sauce."
        },
        4: {
            title: "Chicken Rolls",
            description: "Delicious rolls filled with spiced chicken, herbs, and cheese.",
            image: "chicken rools.jpg",
            ingredients: ["Chicken breast", "Cheese", "Tortilla wraps", "Bell peppers", "Spices"],
            preparation: "Grill the chicken, mix with cheese and spices, and wrap in tortillas."
        },
        5: {
            title: "Chocolate Lava Cake",
            description: "A rich chocolate cake with a gooey molten center.",
            image: "chocolate lava cake.jpg", 
            ingredients: ["Dark chocolate", "Butter", "Sugar", "Eggs", "Flour"],
            preparation: "Melt chocolate and butter, mix with sugar and eggs, bake until the outside is set."
        },
        6: {
            title: "Quesadillas",
            description: "Grilled tortillas filled with cheese and assorted fillings.",
            image: "Quesadillas.jpeg.jpg",
            ingredients: ["Tortillas", "Cheese", "Bell peppers", "Onions", "Spices"],
            preparation: "Fill tortillas with cheese and other fillings, grill until the cheese melts."
        }
    };


    function showPage(page) {
        Object.values(pages).forEach((p) => (p.style.display = "none"));
        pages[page].style.display = "block";
    }

    function showRecipe(recipeId) {
        const recipe = recipeData[recipeId];
        document.getElementById("recipe-title").textContent = recipe.title;
        document.getElementById("recipe-description").textContent = recipe.description;
        document.getElementById("recipe-image").src = recipe.image;
        document.getElementById("preparation-steps").textContent = recipe.preparation;

        const ingredientsList = document.getElementById("ingredients-list");
        ingredientsList.innerHTML = "";
        recipe.ingredients.forEach((ingredient) => {
            const li = document.createElement("li");
            li.textContent = ingredient;
            ingredientsList.appendChild(li);
        });

        showPage("recipeDetail");
    }

    window.showPage = showPage;
    window.showRecipe = showRecipe;
    showPage("home");
});
